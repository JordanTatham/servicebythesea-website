import { WebsiteEditorGuide } from "@/components/website-editor-guide"

export default function EditGuidePage() {
  return <WebsiteEditorGuide />
}
