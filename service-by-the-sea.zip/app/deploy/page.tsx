import { DeploymentInstructions } from "@/components/deployment-instructions"

export default function DeployPage() {
  return <DeploymentInstructions />
}
